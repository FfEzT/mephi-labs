#include <stdbool.h>

#include "./lib/lib_scanf.h"
#include "./lib/stack.h"
#include "el.h"

bool is_math_expr(const char*);
bool calculate(const char*, int* res);
void fill_math(const char*, Stack*);

int main() {
	char* str = get_str("Введите строку > ");
	int res;

	if ( calculate(str, &res) )
		printf("Result: %d\n", res);
	else printf("Incorrect expression\n");

	free(str);

	return 0;
}

void fill_math(const char* str, Stack* obj) {
	unsigned len = strlen(str);

	for (unsigned i = 0; i < len; ++i) {
		if ( strchr("*-+/", str[i]) != NULL ) {
			Stack_el* el = malloc(sizeof(Stack_el));
			el->type = OPERATION;
			el->data = str[i];

			stack_push(obj, el);
		}
		else if (str[i] >= '0' && str[i] <= '9') {
			int res = 0;

			while (i < len && str[i] >= '0' && str[i] <= '9') {
				res *= 10;
				res += str[i++] - '0';
			}

			Stack_el* el = malloc(sizeof(Stack_el));
			el->type = NUMBER;
			el->data = res;
			
			stack_push(obj, el);
		}
	}
}

bool is_math_expr(const char* str) {
	for (unsigned i = 0; str[i] != '\0'; ++i)
		if ( strchr(" \t*-+/1234567890", str[i]) == NULL ) return false;

	return true;
}

bool calculate(const char* str, int* res) {
	bool is_norm = is_math_expr(str);

	Stack nums;
	stack_init(&nums);
	
	Stack math;
	stack_init(&math);
	fill_math(str, &math);

	while (math.size > 0 && is_norm) {
		Stack_el* el = stack_pop(&math);

		if (el->type == NUMBER) stack_push(&nums, el);
		else if (el->type == OPERATION && nums.size > 1) {
			Stack_el* el1 = stack_pop(&nums);
			Stack_el* el2 = stack_pop(&nums);

			Stack_el* new = malloc(sizeof(Stack_el));
			new->type = NUMBER;

			if (el->data == '+') new->data = el1->data + el2->data; 
			else if (el->data == '-') new->data = el1->data - el2->data; 
			else if (el->data == '*') new->data = el1->data * el2->data; 
			else if (el->data == '/' && el2->data != 0) new->data = el1->data / el2->data; 
			else if (el->data == '/' && el2->data == 0) is_norm = false; 

			stack_push(&nums, new);

			free(el1);
			free(el2);
			free(el);
		}
		else if (el->type == OPERATION && nums.size <= 1) is_norm = false, free(el);		
	}

	if (nums.size == 1 && is_norm) {
		Stack_el* tmp = stack_pop(&nums);
		*res = tmp->data;

		free(tmp);
	}
	else is_norm = false;

	stack_free(&math, 1);
	stack_free(&nums, 1);

	return is_norm;
}
