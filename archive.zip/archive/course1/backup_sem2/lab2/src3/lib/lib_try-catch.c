#include "lib_try-catch.h"

jmp_buf _buf;
jmp_buf __buf;
int _exception = 0;
