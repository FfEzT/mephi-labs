#include "stack.h"

void stack_init(Stack* obj) {
	obj->size = 0;
	obj->list = list_init();
}
void stack_free(Stack* obj) {
	obj->size = 0;
	list_free(obj->list);
}

void stack_push(Stack* obj, CLASS data) {
	list_push_back(obj->list, data);
	obj->size = obj->list->size;
}
CLASS stack_pop(Stack* obj) {
	CLASS res = *list_at_last(obj->list);
	list_pop_back(obj->list);
	
	obj->size = obj->list->size;

	return res;
}
