#ifndef _stack
#define _stack

#define CLASS int

#include "./lib/lib_arr.h"
#include "./lib/lib_list(process).h"

typedef struct {
	unsigned size;
	union {
		List* list;
		Array* arr;	
	};
} Stack;


void stack_init(Stack*);
void stack_free(Stack*);
void stack_push(Stack*, CLASS data);
CLASS stack_pop(Stack*);

#endif
