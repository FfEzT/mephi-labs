#include "./lib_arr.h"
#include "string.h"

static void arr_check(Array* arr);

Array* arr_init() {
	Array* ptr = malloc(sizeof(Array));
	if (ptr == NULL) throw(null_ptr);

	ptr->size = (ptr->count = 0)+1;
	ptr->ptr = calloc(ptr->size, sizeof(CLASS));
	if (ptr->ptr == NULL) throw(null_ptr);

	return ptr;
}

void arr_free(Array* arr) {
    arr->count = arr->size = 0;
    free(arr->ptr);
    free(arr);
}

void arr_print(Array* arr) {
    printf("Size: %d\tCount: %d\n", arr->size, arr->count);

    for (int i = 0; i < arr->count; ++i)
        printf("arr[%d]: %d\n", i, arr->ptr[i]);
}

void arr_insert(Array* arr, int index, CLASS value) {
    if (index >= arr->count) {
        arr->ptr[arr->count] = value;
        ++(arr->count);

        arr_check(arr);
    }
    else arr->ptr[index] = value;
}

static void arr_check(Array* arr) {
    if (arr->count < arr->size / 2) {
        CLASS* new_arr = calloc(arr->size / 2 + 1, sizeof(CLASS));
        if (!new_arr) throw(null_ptr);

        arr->size = arr->size / 2 + 1;

        memcpy(new_arr, arr->ptr, sizeof(CLASS) * arr->count);
        free(arr->ptr);
        arr->ptr = new_arr;
    }
    else if (arr->count == arr->size) {
        CLASS* new_arr = calloc(arr->size * 2, sizeof(CLASS));
        if (!new_arr) throw(null_ptr);

        arr->size = arr->size * 2;

        memcpy(new_arr, arr->ptr, sizeof(CLASS) * arr->count);
        free(arr->ptr);
        arr->ptr = new_arr;
    }
}

void arr_delete(Array* arr, int index) {
    if (index >= arr->count) return;

    CLASS* new_arr = calloc(arr->size, sizeof(CLASS));
    if (!new_arr) throw(null_ptr);

    memcpy(new_arr, arr->ptr, sizeof(CLASS) * index);
    memcpy(
        new_arr + index,
        arr->ptr + index + 1,
        sizeof(CLASS) * (arr->count - index - 1)
    );

    for (int i = arr->count - 1; i >= 0; --i) {
        if (!new_arr[i]) --(arr->count);
        else break;
    }

    free(arr->ptr);
    arr->ptr = new_arr;
    arr_check(arr);
}
