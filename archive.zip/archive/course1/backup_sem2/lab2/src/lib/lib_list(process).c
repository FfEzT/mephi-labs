#include "lib_list(process).h"

List* list_init() {
    List* res = malloc(sizeof(List));
    if (res == NULL) throw(null_ptr);

    res->size = 0;
    res->first = res->last = NULL;

    return res;
}

void list_print(List* list) {
    Node* temp = list->first;

    printf("Size: %d\n\n", list->size);
    for (unsigned i = 0; temp; ++i) {
        printf("list[%u]:%3d\n", i, temp->data);
        temp = temp->next;
    }
}

void list_push_front(List* list, CLASS value) {
    Node* node = malloc(sizeof(Node));
    if (node == NULL) throw(null_ptr);

    node->next = list->first;
    node->data = value;

    list->first = node;

    if (list->size == 0)
        list->last = node;

    ++list->size;
}

void list_push_back(List* list, CLASS value) {
    Node* node = malloc(sizeof(Node));
    if (node == NULL) throw(null_ptr);

    node->next = NULL;
    node->data = value;

    if (list->size == 0)
        list->first = node;
    else if (list->size >= 1)
        list->last->next = node;

    list->last = node;

    ++list->size;
}

void list_pop_front(List* list) {
    if (list->size > 0) {
        Node* temp = list->first->next;

        free(list->first);
        list->first = temp;

        --list->size;
    }
}

void list_pop_back(List* list) {
	if (list->first == list->last) {
		free(list->first);
		
		list->first = list->last = NULL;
		list->size = 0;
	}
    else if (list->size > 0) {
        Node* temp = list->first;
        
        while (temp->next != list->last)
            temp = temp->next;

        temp->next = NULL;
        free(list->last);
        list->last = temp;

        --list->size;
    }
}

// Check
void list_add(List* list, unsigned index, CLASS value) {
    //if (index >= list->size) return;
    
    Node* temp = list->first;
    
    for (unsigned i = 0; i < index - 1; ++i)
        temp = temp->next;

    Node* node = malloc(sizeof(Node));
    if (node == NULL) throw(null_ptr);

    node->next = temp->next;
    node->data = value;

    temp->next = node;
}

// Check (while != NULL)
void list_delete(List* list, unsigned index) {
    if (index >= list->size) return;

    Node* temp = list->first;

    for (unsigned i = 0; i < index; ++i) // mb index-1
        temp = temp->next;

    Node* deleted = temp->next;

    temp->next = deleted->next;

    --list->size;
    free(deleted);
}

// TODO return CLASS?
Node* list_at(List* list, unsigned index) {
    if (index >= list->size) return NULL;
    
    Node* temp = list->first;
    for (unsigned i = 0; i <= index; ++i) temp = temp->next;

    return temp;
}

CLASS* list_at_last(List* list) {
	return list->size > 0? &list->last->data : NULL;
}


int list_search(List* list, CLASS value) {
    Node* temp = list->first;

    for (unsigned i = 0; temp->next; ++i)
        if (temp->data == value) return i;

    return -1;
}

void list_free(List* list) {
    if (list->size == 1)
        free(list->first);
    else if (list->size > 1) {
        Node* first = list->first;
        Node* second = list->first->next;

        while (second != NULL) {
            free(first);
            first = second;
            second = second->next;
        }
        free(first);
    }

    free(list);
}
