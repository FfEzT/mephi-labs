#ifndef _lib_arr
#define _lib_arr

#include <stdio.h>
#include <malloc.h>

#include "lib_try-catch.h"

#define CLASS int

typedef struct {
    CLASS* ptr;
    int count;
    int size;
} Array;

Array* arr_init();
void arr_free(Array*);
void arr_print(Array*);
void arr_insert(Array*, int index, CLASS value);
void arr_delete(Array*, int index);

#endif
