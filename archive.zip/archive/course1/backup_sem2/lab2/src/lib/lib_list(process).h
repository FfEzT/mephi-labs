#ifndef _lib_list
#define _lib_list

#include <stdlib.h>
#include <malloc.h>
#include <stdarg.h>
#include <stdio.h>

#include "lib_try-catch.h"

#define CLASS int

// TODO add const
typedef struct Node {
    struct Node* next;
    CLASS data;
} Node;
typedef struct {
    Node* first;
    Node* last;
    unsigned size;
} List;

List* list_init();
void list_print(List* list);
void list_push_front(List* list, CLASS value);
void list_push_back(List* list, CLASS value);
void list_pop_front(List* list);
void list_pop_back(List* list);
void list_add(List* list, unsigned index, CLASS value);
void list_delete(List* list, unsigned index);
Node* list_at(List* list, unsigned index);
CLASS* list_at_last(List* list);
int list_search(List* list, CLASS value);
void list_free(List* list);

#endif
