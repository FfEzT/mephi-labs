#include "lib_try-catch.h"

jmp_buf _buf;
int _exception = 0;
