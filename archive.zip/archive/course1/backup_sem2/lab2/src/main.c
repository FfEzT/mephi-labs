#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "stack.h"
#include "lib/lib_scanf.h"
#include "lib/lib_list(process).h"

void fill_operations(Stack* obj, const char* str) {
	for (int i = strlen(str)-1; i > 0; --i) {
		if (
			strchr("+-*/", str[i]) != NULL
		) {
			stack_push(obj, str[i]);
		}
	} 
}

void fill_numbers(Stack* obj, const char* _str) {
	char* str = strdup(_str);
	List* list = list_init();
	
	char* word = strtok(str, " \t+-*/");
	while (word != NULL) {
		// list_push_front(list, atoi(word));
		list_push_front(list, 1);
		word = strtok(NULL, " \t+-*/");	
	}

	Node* ptr = list->first;
	while (ptr != NULL) {
		stack_push(obj, ptr->data);
		ptr = ptr->next;
	}

	list_free(list);
	free(str);
}

bool check_op_and_num(const Stack* numbers, const Stack* operations) {
	return numbers->size == operations->size+1;
}

int get_result(Stack* numbers, Stack* operations) {
	while (operations->size > 0) {
		char op = stack_pop(operations);

		int new_num;
		int num1 = stack_pop(numbers);
		int num2 = stack_pop(numbers);
		
		if (op == '+') new_num = num1 + num2;
		else if (op == '-') new_num = num1 - num2;
		else if (op == '*') new_num = num1 * num2;
		else if (op == '/') new_num = num1 / num2;

		stack_push(numbers, new_num);
	}

	return stack_pop(numbers);
}

void process(const char* str, int** res) {
	Stack numbers;
	stack_init(&numbers);
	fill_numbers(&numbers, str);
	
	Stack operations;
	stack_init(&operations);
	fill_operations(&operations, str);

	if ( check_op_and_num(&numbers, &operations) ) {
		*res = malloc(sizeof(int));
		**res = get_result(&numbers, &operations);
	}
	else printf("Вы ввели неверное выражение☺\n");

	stack_free(&numbers);
	stack_free(&operations);
}

bool is_math_expr(const char* str) {
	for (unsigned i = 0; str[i] != '\0'; ++i)
		if ( strchr("0123456789 \t+-*/", str[i]) == NULL ) return false;

	return true;
}

int main() {
	char* str = get_str("Введите мат. выражение > ");
	int* res = NULL;

	if ( is_math_expr(str) ) process(str, &res);
	else printf("Вы ввели неверное выражение☺\n");

	if (res) printf("Результат: %d\n", *res), free(res);
	
	free(str);

	return 0;
}
