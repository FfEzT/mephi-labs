#include "stack.h"

void stack_init(Stack* obj) {
	obj->size = 0;
	obj->arr = arr_init();
}
void stack_free(Stack* obj) {
	obj->size = 0;
	arr_free(obj->arr);
}

void stack_push(Stack* obj, CLASS data) {
	arr_insert(obj->arr, obj->arr->count, data);
	obj->size = obj->arr->count;
}

CLASS stack_pop(Stack* obj) {
	CLASS res = obj->arr->ptr[obj->arr->count-1];
	arr_delete(obj->arr, obj->arr->count-1);
	
	obj->size = obj->arr->count;

	return res;
}
