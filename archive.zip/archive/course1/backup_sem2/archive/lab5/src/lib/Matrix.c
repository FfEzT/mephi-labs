#include <stdlib.h>
#include <stdio.h>

#include "Matrix.h"

typedef struct Matrix {
	unsigned size;
	Array* arr;
	Array* ptr;	
} Matrix;

static int mini(int a, int b) {
	return a <= b ? a : b;
}

static int get_count_output(Matrix* a, unsigned from) {
	int count = 0;

	Array* ptr = a->arr->ptr[from];
	for (unsigned i = 0; i < a->size; ++i)
		if (ptr->ptr[i]) ++count;

	return count;
}

static int get_to(Matrix* a, unsigned from, unsigned num) {
	Array* ptr = a->arr->ptr[from];

	for (unsigned i = 0, count = 0; i < a->size; ++i) {
		if (ptr->ptr[i]) {
			if (count == num) return i;
			else ++count;
		}
	}

	return -1;
}

static int absolute(int a) {
	return a >= 0? a : -a;
}

static int search_index_point(Matrix* a, Point* el) {
	for (unsigned i = 0; i < a->size; ++i) {
		Point* lol = a->ptr->ptr[i];
		if (lol->cord[0] == el->cord[0] && lol->cord[1] == el->cord[1])
			return i;
	}
	return -1;
}

static Point* find_by_cords(Matrix* a, unsigned cord[2]) {
	for (unsigned i = 0; i < a->size; ++i) {
		Point* hz = a->ptr->ptr[i];

		if (hz->cord[0] == cord[0] && hz->cord[1] == cord[1])
			return hz;
	}
	return NULL;
}

Matrix* matr_init() {
	Matrix* res = malloc(sizeof(Matrix));

	res->size = 0;

	res->ptr = malloc(sizeof(Array));
	arr_init(res->ptr);
	
	res->arr = malloc(sizeof(Array));
	arr_init(res->arr);

	return res;
}

Matrix* matr_free(Matrix* a) {
	for (unsigned i = 0; i < a->size; ++i) {
		Array* lol = a->arr->ptr[i];
		arr_free(lol, 0);
	}
	
	arr_free(a->arr, 1);
	free(a->arr);

	arr_free(a->ptr, 1);
	free(a->ptr);

	free(a);

	return NULL;
}

void matr_show(Matrix* a) {
	for (unsigned i = 0; i < a->size; ++i) {
		Array* lol = a->arr->ptr[i];
		
		for (unsigned j = 0; j < a->size; ++j)
			printf("%u ", (unsigned)(lol->ptr[j]));
			
		printf("\n");
	}

	for (unsigned i = 0; i < a->size; ++i) {
		Point* tmp = a->ptr->ptr[i];
		printf("%u: (%u, %u) %u\n", i, tmp->cord[0], tmp->cord[1], tmp->type);
	}
}

bool matr_insert_v(Matrix* a, unsigned x, unsigned y, enum Type type) {
	unsigned temp[] = {x, y};

	if (find_by_cords(a, temp))
		return false;

	Point* new = malloc(sizeof(Point));
	new->cord[0] = x;
	new->cord[1] = y;
	new->type = type;
	
	arr_insert(a->ptr, a->size, new);

	Array* row = malloc(sizeof(Array));
	arr_init(row);
	for (unsigned i = 0; i < a->size+1; ++i) 
		arr_insert(row, i, 0);

	for (unsigned i = 0; i < a->size; ++i) {
		Array* row = a->arr->ptr[i];
		arr_insert(row, a->size, 0);
	} 
	arr_insert(a->arr, a->size, row);
	
	++a->size;

	return true;
}

bool matr_del_v(Matrix* a, unsigned num) {
	if (num >= a->size) return false;

	for (unsigned i = 0; i < a->size; ++i) {
		Array* temp = a->arr->ptr[i];
		arr_delete(temp, num, 0);
	}
	Array* temp = a->arr->ptr[num];
	arr_free(temp, 0);
	arr_delete(a->arr, num, 1);
	arr_delete(a->ptr, num, 1);

	--a->size;

	return true;
}

Array* matr_get_near(Matrix* a, unsigned num) {
	if (num >= a->size) return NULL;


	Array* new = malloc(sizeof(Array));
	arr_init(new);
	
	Point* eq = a->ptr->ptr[num];
	for (unsigned i = 0; i < a->size; ++i) {
		if (i == num) continue;

		Point* ptr = a->ptr->ptr[i];

		if (eq->cord[0] == ptr->cord[0] && absolute(eq->cord[1] - ptr->cord[1]) == 1 ||
		    eq->cord[1] == ptr->cord[1] && absolute(eq->cord[0] - ptr->cord[0]) == 1 ) {
		 	arr_insert(new, new->count, ptr);   	
	    }
	}

	return new;
}

Array* matr_get_input(Matrix* a) {
	Array* new = malloc(sizeof(Array));
	arr_init(new);
	
	for (unsigned i = 0; i < a->size; ++i) {
		Point* ptr = a->ptr->ptr[i];

		if (ptr->type == START)
		 	arr_insert(new, new->count, ptr);   	
	}

	return new;
}

Array* matr_get_output(Matrix* a) {
	Array* new = malloc(sizeof(Array));
	arr_init(new);
	
	for (unsigned i = 0; i < a->size; ++i) {
		Point* ptr = a->ptr->ptr[i];

		if (ptr->type == END)
		 	arr_insert(new, new->count, ptr);   	
	}

	return new;
}

void matr_add_u(Matrix* a, unsigned from, Point* p_to) {
	int to = search_index_point(a, p_to);

	Array* ar = a->arr->ptr[from];
	ar->ptr[to] = (void*)1;	
}

bool matr_del_u(Matrix* a, unsigned from, unsigned to) {
	if (from >= a->size || to >= a->size || from == to) return false;

	Array* ar = a->arr->ptr[from];
	ar->ptr[to] = (void*)0;

	return true;
}

bool matr_connect(Matrix* a, unsigned _from) {
	if (_from >= a->size) return false;
	
	{
		Point* aga = a->ptr->ptr[_from];
		if (aga->type == END) return true;
	}
	
	unsigned from = _from;
	bool status = false;

	enum Flag {
		CLEAR,
		// GREY,
		BLACK
	};

	enum Flag* colour = calloc(a->size, sizeof(enum Flag));
	colour[from] = BLACK;
	// colour[from] = GREY;

	Array dec;
	arr_init(&dec);
	arr_insert(&dec, dec.count, (void*)from);

	while(dec.count) {
		Array* arr = a->arr->ptr[from];

		for (unsigned i = 0; i < a->size; ++i) {
			if (arr->ptr[i]) {
				Point* b = a->ptr->ptr[i];
				if (b->type == END) {
					status = true;
					break;
				}
			}
			if (arr->ptr[i] && colour[i] == CLEAR ) {
				from = i;
				colour[from] = BLACK;
				// colour[from] = GREY;
				arr_insert(&dec, dec.count, (void*)from);
				break;
			}
			else if (i == a->size-1) {
				// colour[from] = BLACK;
				arr_delete(&dec, dec.count-1, 0);
				if (dec.count-1 >= 0)
					from = (unsigned)dec.ptr[dec.count-1];
			}
		}

		if (status) break;
	}

	arr_free(&dec, 0);
	free(colour);
	return status;
}

Array* matr_path(Matrix* a, Point* _from, Point* _to) {
	const int infinity = 100000;
	
	int from = search_index_point(a, _from);
	unsigned to = search_index_point(a, _to);

	int* distance = calloc(a->size, sizeof(int));
	for (unsigned i = 0; i < a->size; ++i)
		distance[i] = infinity;

	distance[from] = 0;

	int* colour = calloc(a->size, sizeof(int));

	Array* stack = malloc(sizeof(Array));
	arr_init(stack);

	arr_insert(stack, 0, (void*)from);

	do {
		Array* ptr = a->arr->ptr[from];
		for (unsigned i = 0; i < a->size; ++i) {
			if (ptr->ptr[i]) {
				arr_insert(stack, stack->count, (void*)i);
				distance[i] = mini(distance[i], distance[from]+1);
			}
		}
		from = (int)stack->ptr[0];
		colour[from] = 1;
		arr_delete(stack, 0, 0);
	} while (stack->count);

	for (unsigned i = 0; i < a->size; ++i)
		printf("dis %d", distance[i]);

	if (distance[to] != infinity) {
		bool flag = true;
		while (flag) {
			for (unsigned i = 0; i < a->size; ++i) {
				if (i == to) continue;
				
				Array* ptr = a->arr->ptr[i];
				if (ptr->ptr[to] && distance[i] == distance[to] - 1) {
					arr_insert(stack, stack->count, (void*)to);
					to = i;
					break;
				}
				else if (i == a->size - 1) {
					flag = false;
					break;
				}
			}
		}
	}
	else {
		arr_free(stack, 0);
		free(stack);
		stack = NULL;		
	}

	free(colour);
	free(distance);

	return stack;





/*
	for (unsigned i = 0; i < a->size; ++i) {
		int v = -1;

		for (unsigned j = 0; j < a->size; ++j)
			if(!colour[j] && (v == -1 || distance[j] < distance[v]) )
				v = j;

		if (distance[v] == infinity) break;
		colour[v] = 1;

		int tmp = get_count_output(a, v);
		for (int j = 0; j < tmp; ++j) {
			int to = get_to(a, from, j);

			if (distance[v]+1 < distance[to]) {
				distance[to] = distance[v] + 1;
				pred[to] = v;
			}
		}
	}

	remake: {
		for (unsigned i = 0; i < a->size; ++i)
			printf("%d ", distance[i]);
		printf("\n");

		for (unsigned i = 0; i < a->size; ++i)
			printf("%d ", pred[i]);
		printf("\n");

		for (unsigned i = 0; i < a->size; ++i)
			printf("%d ", colour[i]);
		printf("\n");

		free(colour);
		free(distance);
		free(pred);

		return NULL;
	}
*/
}
