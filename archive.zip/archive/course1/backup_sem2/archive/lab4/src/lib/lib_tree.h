#ifndef _lib_tree
#define _lib_tree

#include <stdbool.h>

#include "lib_list.h"

typedef struct tNode {
	char* key;
	struct tNode* left, *right, *parrent;
	List* ls;
} tNode;

/*typedef struct {
	char** str; unsigned index;
} Data;*/

void tree_init(tNode*);
void tree_free(tNode*);
void tree_print(tNode*);
void tree_print_(tNode*);
tNode* tree_insert(tNode*, const char* key, const char* data);
bool tree_delete(tNode**, const char* key);
tNode* tree_find_by_key(tNode*, const char* key);
tNode* tree_find(tNode*, const char* key); // TODO return key

#endif
