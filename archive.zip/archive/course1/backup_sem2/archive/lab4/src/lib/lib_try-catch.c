#include "lib_try-catch.h"

int _exception = 0;
