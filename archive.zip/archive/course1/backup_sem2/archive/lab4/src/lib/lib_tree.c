#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "lib_tree.h"

static tNode* get_max(tNode* a) {
	if (a == NULL) return NULL;
	if (a->right == NULL) return a;
	return get_max(a->right);
}

static tNode* get_min(tNode* a) {
	if (a == NULL) return NULL;
	if (a->left == NULL) return a;
	return get_min(a->left);
}

static tNode* succ(tNode* a) {
	tNode* p = a, *l = NULL;
	if (p->right) return get_min(p->right);
	l = p->parrent;

	while (l && (p == l->right) ) {
		p = l;
		l = l->parrent;
	}
	return l;
}

static void delete_node(tNode* a) {
	free(a->key);
	list_free(a->ls, 1);
	free(a->ls);
}

void tree_init(tNode* a) {
	a->key = a->left = a->right = a->parrent = NULL;
	a->ls = malloc(sizeof(List));
	list_init(a->ls);
}

void tree_free(tNode* a) {
	if (a == NULL) return;
	tree_free(a->left);
	tree_free(a->right);

	{
		free(a->key);
		list_free(a->ls, 1);
		free(a->ls);
		free(a);
	}
}

tNode* tree_insert(tNode* a, const char* key, const char* data) {
	if (a == NULL) {
		a = malloc(sizeof(tNode));
		tree_init(a);
		
		a->key = strdup(key);
		list_push_back(a->ls, strdup(data) );
	}
	else if (strcmp(a->key, key) == 0)
		list_push_back(a->ls, strdup(data) );
	else if (strcmp(a->key, key) > 0) {
		a->left = tree_insert(a->left, key, data);
		a->left->parrent = a;
	}
	else if (strcmp(a->key, key) < 0) {
		a->right = tree_insert(a->right, key, data);
		a->right->parrent = a;
	}

	return a;
}

static void helping(tNode* a, int b, int lol) {
	if (a == NULL) return;
	for (int i = 0; i < b; ++i) printf("\t");

	if (lol == 1) printf("L: ");
	if (lol == 2) printf("R: ");

	if (a->key) {
		printf("%s: ", a->key);
		Node* node = a->ls->first;

		while (node) {
			printf("%s ", node->data);
			node = node->next;
		}

		printf("\n");
	}

	if (a->right) helping(a->right, 1+b, 2);
	if (a->left) helping(a->left, 1+b, 1);
}

void tree_print_(tNode* a) {
	helping(a, 0, 0);
}

void tree_print(tNode* a) {
	if (a == NULL) return;
		
	tree_print(a->left);

	if (a->key) {
		printf("%s: ", a->key);
		Node* node = a->ls->first;

		while (node) {
			printf("%s ", node->data);
			node = node->next;
		}

		printf("\n");
	}
	
	tree_print(a->right);
}

bool tree_delete(tNode** a, const char* key) {
	tNode* l = NULL, *m = NULL;
	l = tree_find_by_key(*a, key);

	if (l == NULL) return false;

	list_pop_front(l->ls, 1);
	if (l->ls->size != 0) return true;


	if ( (l->left == NULL) && (l->right == NULL) ) {
		m = l->parrent;

		if (m) {
			if (l == m->right) m->right = NULL;
			else m->left = NULL;
		}
		else *a = NULL;


		delete_node(l);
		free(l);
	}
	else if ( (l->left == NULL) && (l->right)) {
		m = l->parrent;

		if (m) {
			if (l == m->right) m->right = l->right;
			else m->left = l->right;

			l->right->parrent = m;
		}
		else {
			l->right->parrent = *a;
			*a = l->right;
		}
		
		delete_node(l);
		free(l);
	}
	else if ( (l->right == NULL) && (l->left)) {
		m = l->parrent;

		if (m) {
			if (l == m->right) m->right = l->left;
			else m->left = l->left;

			l->left->parrent = m;
		}
		else {
			l->left->parrent = *a;
			*a = l->left;
		}

		delete_node(l);
		free(l);
	}
	else if (l->left && l->right) {
		m = succ(l);

		free(l->key);
		l->key = strdup(m->key);
		{
			for (Node* lol = m->ls->first; lol; lol = lol->next)
				list_push_back(
					l->ls,
					strdup(lol->data)
				);
		}
		// TODO
		if (l == m->parrent)
			l->right = m->right;
		else if (m->right == NULL)
			m->parrent->left = NULL;
		else m->parrent->right = m->right;

		
		delete_node(m);
		free(m);
	}

	return true;
}

tNode* tree_find_by_key(tNode* a, const char* key) {
	if (a == NULL || a->ls->size == 0) return NULL;
	
	if ( strcmp(a->key, key) == 0 )
		return a;

	tNode* res;
	if (strcmp(a->key, key) > 0 )
		res = tree_find_by_key(a->left, key);
	else if (strcmp(a->key, key) < 0 )
		res = tree_find_by_key(a->right, key);

	return res;
}

tNode* tree_find(tNode* a, const char* key) {
	int conditional = strcmp(a->key, key);

	if (conditional == 0) return a;
	if (conditional < 0) {
		if (!a->right) return a;
		return tree_find(a->right, key);
	}
	if (conditional > 0) {
		if (!a->left) return a;
		return tree_find(a->left, key);
	}
}
