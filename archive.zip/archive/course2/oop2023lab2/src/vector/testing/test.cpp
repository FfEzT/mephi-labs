#include <gtest/gtest.h>

#include "Vector/vector.h"
#include "vector"
#include "Card/card.h"
#include <algorithm>

template <typename T>
void log(T& a)
{
    std::cout << "size " << a.size() << '\n';
    std::cout << "capa " << a.capacity() << '\n';
    for (auto it : a) {
        std::cout << it << '\n';
    }

    std::cout << '\n';
}

TEST(a,v) {
    Flib::Vector<int> vec1(5);
    vec1[0] = 5;
    vec1[2] = 55;
    vec1[3] = 51;
    vec1[4] = 15;

    log(vec1);

    vec1.insert(1, 100);
    log(vec1);
    vec1.remove(3);
 
    log(vec1);
}

