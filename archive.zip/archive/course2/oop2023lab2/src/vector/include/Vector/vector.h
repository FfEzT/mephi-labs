#ifndef _vector
#define _vector

#include <utility>
#include <memory>

namespace Flib {
    template <typename T>
    struct RawMemory {
        T* data = nullptr;
        size_t capacity = 0;

        RawMemory() = default;

        RawMemory(size_t n)
            : data( allocate(n) ), capacity(n)
        {}

        ~RawMemory()
        {
            deallocate(data);
        }

        RawMemory(const RawMemory&) = delete;
        RawMemory& operator=(const RawMemory&) = delete;

        RawMemory(RawMemory&& obj) noexcept
        {
            swap(*this, obj);
        }

        RawMemory& operator=(RawMemory&& obj)
        {
            RawMemory::swap(*this, obj);
            return *this;
        }


        static T* allocate(size_t n)
        {
            return static_cast<T*>( operator new( n * sizeof(T) ) );
        }

        static void deallocate(T* buf)
        {
            operator delete(buf);
        }

        static void swap(RawMemory<T>& a, RawMemory<T>& b) noexcept
        {
            if (&a == &b)
                return;

            std::swap(a.data, b.data);
            std::swap(a.capacity, b.capacity);
        }


        const T* operator+(size_t i) const {return data + i;}
        T* operator+(size_t i) {return data + i;}


        const T& operator[](size_t i) const {return data[i];}
        T& operator[](size_t i) {return data[i];}
    };

    template <typename T>
    class Vector {
        RawMemory<T> data;
        size_t count_ = 0;

    public:
        Vector() = default;

        Vector(size_t size)
            : data(size), count_(size)
        {
            /*size_t i = 0;

            try {
                for (; i != size; ++i)
                    construct(data + i);
            }
            catch (...) {
                for (size_t j = 0; j != i; ++j)
                    destroy(data + j);
                throw;
            }*/

            std::uninitialized_value_construct_n(
                data.data, size
            );
        }

        Vector(const Vector& oth)
            : data(oth.count_), count_(oth.count_)
        {
            /*
            size_t i = 0;
            try {
                for (; i != count_; ++i)
                    construct(data + i, oth.data[i]);
            }
            catch (...) {
                for (size_t j = 0; j != i; ++j)
                    destroy(data + j);
                throw;
            }
            */

            std::uninitialized_copy_n(
                oth.data.data, oth.count_, data.data
            );
        }

        Vector(Vector&& obj) noexcept
        {
            swap(*this, obj);
        }

        ~Vector()
        {
            /*
            for (size_t i = 0; i < count_; ++i)
                destroy(data + i);
            */
            std::destroy_n(data.data, count_);
        }

        Vector& operator=(const Vector& obj)
        {
            if (data.capacity < obj.count_) {
                Vector tmp(obj);
                swap(*this, tmp);
            }
            else {
                for (size_t i = 0; i < obj.count_ && i < count_; ++i) {
                    data[i] = obj[i];
                }

                if (count_ < obj.count_) {
                    std::uninitialized_copy_n(
                        obj.data.data + count_,
                        obj.count_ - count_,
                        data.data + count_
                    );
                }
                else if (count_ == obj.count_) {
                    std::destroy_n(
                        data.data + obj.count_,
                        count_ - obj.count_
                    );
                }
            }

            return *this;
        }

        Vector& operator=(Vector&& obj) noexcept
        {
            Vector::swap(*this, obj);
            return *this;
        }

        Vector operator+(const Vector& obj) const
        {
            Vector result;

            for (const auto& it : *this) {
                result.pushBack(it);
            }
            for (const auto& it : obj) {
                result.pushBack(it);
            }

            return result;
        }

        const T& operator[](size_t index) const { return data[index]; }
        T& operator[](size_t index) { return data[index]; }


        size_t size() const { return count_; }
        size_t capacity() const { return data.capacity; }

        void shrinkToFit() {}
        void reserve(size_t n)
        {
            if (n <= capacity())
                return;

            RawMemory<T> other(n);

            /*
            size_t i = 0;
            try {
                for (; i != count_; ++i)
                    construct(other + i, data[i]);
            }
            catch (...) {
                for (size_t j = 0; j != i; ++j)
                    destroy(other + j);
                throw;
            }
            */
            std::uninitialized_move_n(
                data.data, count_, other.data
            );

            /*
            for (size_t i = 0; i != count_; ++i)
                destroy(data + i);
            */
            std::destroy_n(data.data, count_);

            RawMemory<T>::swap(data, other);
        }

        void resize(size_t n)
        {
            reserve(n);

            if (count_ < n) {
                std::uninitialized_value_construct_n(
                    data + count_, n - count_
                );
            }
            else if (count_ > n) {
                std::destroy_n(
                    data + n, count_ - n
                );
            }
            count_ = n;
        }


        void insert(size_t index, T el)
        {
            pushBack(el);

            std::swap(
                data[index], data[count_ - 1]
            );
        }

        void remove(size_t index)
        {
            std::destroy_at(data + index);

            std::uninitialized_move_n(
                data + index + 1,
                count_ - index - 1,
                data + index
            );
            --count_;
        }

        // TODO ���������� ��� � ���� �������?
        void pushBack(T el)
        {
            checkSizeCapacity();

            new (data + count_) T( std::move(el) );
            ++count_;
        }



        void popBack()
        {
            std::destroy_at(
                data + count_ - 1
            );
            --count_;
        }


        bool empty() const { return count_; }


        const T* begin() const { return data+0; }
        T* begin()             { return data+0; }

        const T* end() const { return data + count_; }
        T* end()             { return data + count_; }

        static void swap(Vector<T>& a, Vector<T>& b) noexcept
        {
            RawMemory<T>::swap(a.data, b.data);
            std::swap(a.count_, b.count_);
        }

    private:
        void checkSizeCapacity()
        {
            if (count_ != data.capacity)
                return;

            size_t newCount = count_ == 0 ? 1 : count_ * 2;
            reserve(newCount);
        }

        // TODO delete construct and destroy
        void construct(T* ptr)
        {
            new (ptr) T();
        }
        
        void construct(T* ptr, const T& el)
        {
            new (ptr) T(el);
        }

        void construct(T* ptr, T&& el)
        {
            new (ptr) T(std::move(el));
        }

        void destroy(T* ptr)
        {
            ptr->~T();
        }

    };
}


#endif // !_vector
