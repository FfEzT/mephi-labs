#include "Deck/deck.h"

#include <map>
#include <set>
#include <random>
#include <iomanip>
#include <algorithm>
#include <unordered_set>
#include <unordered_map>

#include "Utils/utils.h"
#include "Card/hashCard.h"

using namespace prog2;
using GROUP = Card::GROUP;

namespace {
    std::unordered_map<
        GROUP,
        std::unordered_set<unsigned>
    > getAllAviableCards()
    {
        using vector_unsigned = std::unordered_set<unsigned>;

        std::unordered_map<
            GROUP, vector_unsigned
        > table;

        vector_unsigned temp;
        temp.reserve(Card::RANK_COUNT);

        for (unsigned i = 1; i <= Card::RANK_COUNT; ++i)
            temp.insert(i);

        /*for (auto& it : table) {
            it.second = temp;
        }*/
        table[GROUP::CLUB] = temp;
        table[GROUP::DIAMOND] = temp;
        table[GROUP::HEART] = temp;
        table[GROUP::SPADE] = temp;

        return table;
    }

    GROUP getRandomGroupByMap(
        const std::unordered_map<
        GROUP,
        std::unordered_set<unsigned>
        >& table
    )
    {
        unsigned groupNumeric = utils::getRandom() % table.size();

        auto itTmp = std::next(
            table.begin(),
            groupNumeric
        );

        return itTmp->first;
    }

    unsigned getRundomNumeric(size_t sizeOfSet) {
        if (!sizeOfSet)
            std::invalid_argument("size == 0");

        if (sizeOfSet == 1)
            return 0;

        return utils::getRandom() % (sizeOfSet - 1);
    }
}

Deck::Deck(size_t count)
{
    if (count > maxPossibleCardCount)
        throw std::invalid_argument("Very big count for those Cards");

    auto table = getAllAviableCards();

    for (int i = 0; i < count;) {
        GROUP group = getRandomGroupByMap(table);

        std::unordered_set<unsigned>& aviableRanks = table[group];

        if (aviableRanks.empty()) {
            table.erase(group);
            continue;
        }

        auto itRandomNumber = std::next(
            aviableRanks.begin(),
            getRundomNumeric(aviableRanks.size())
        );

        unsigned rank = *itRandomNumber;
        aviableRanks.erase(itRandomNumber);

        // TODO just pushBack
        deck.pushBack(
            Card(group, rank)
        );

        ++i;
    }
}



Deck Deck::operator+(const Deck& obj) const
{
    Deck res;

    res.deck = deck + obj.deck;

    return res;
}

Deck& Deck::operator>>(Deck& obj)
{
    obj.deck.insert( 0, std::move(deck[0]) );
    deck.remove(0);

    return obj;
}

Card& Deck::operator[](size_t number)
{
    if (number >= deck.size())
        throw std::out_of_range("too big [number]");

    return deck[number];
}

const Card& Deck::operator[](size_t number) const
{
    if (number >= deck.size())
        throw std::out_of_range("too big [number]");

    return deck[number];
}



Deck& Deck::sort()
{
    std::sort(deck.begin(), deck.end());

    return *this;
}

Deck& Deck::shuffle()
{
    std::random_device rd;
    std::mt19937 generator(rd());

    std::ranges::shuffle(deck, generator);

    return *this;
}

Deck Deck::extractByGroup(Card::GROUP group)
{
    Deck res;
    Flib::Vector<Card> currentDeck;

    for (auto& it : deck) {
        const Card& card = it;
        const GROUP& groupInDeck = card.getGroupRank().first;

        if (groupInDeck == group)
            res.deck.pushBack( std::move(it) );
        else currentDeck.pushBack( std::move(it) );
    }

    deck = currentDeck;

    return res;
}

Deck& Deck::deleteCard(size_t number)
{
    if (number >= deck.size())
        throw std::out_of_range("too big [number]");

    deck.remove(number);

    return *this;
}

bool Deck::isAllUniqueCards() const
{
    std::unordered_set<Card, HashCard> set;

    for (const auto& it : deck) {
        const Card& card = it;
        auto findIt = set.find(card);

        if (findIt == set.end())
            set.emplace(card);
        else
            return false;
    }

    return true;
}

Deck& prog2::Deck::putCard(Card card)
{
    deck.insert(0, std::move(card));

    return *this;
}

std::ostream& prog2::operator<<(std::ostream& os, const Deck& obj)
{
    bool isFirstPrint = true;
    size_t i = 0;

    for (auto& pair : obj.deck) {
        if (isFirstPrint) {
            isFirstPrint = false;
        }
        else os << '\n';

        os << std::setw(2) << i++ << ": " << pair;
    }

    return os;
}

std::istream& prog2::operator>>(std::istream& stream, Deck& obj)
{
    int size;
    stream >> size;

    if (stream.good()) {
        obj = Deck(size);
    }
    else {
        stream.setstate(std::ios::failbit);
    }

    return stream;
}