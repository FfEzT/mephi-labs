#ifndef _deck
#define _deck

#include <iostream>
#include <unordered_set>
#include <unordered_map>
#include <map>

#include <Card/card.h>

namespace prog2 {
    class Deck {
        using GROUP = Card::GROUP;

        // !int
        std::map<int, Card> deck;

        static int getNumericFirstCard(const Deck& obj);

    public:
        const static size_t maxPossibleCardCount = Card::GROUP_COUNT * Card::RANK_COUNT;

        Deck(size_t count);
        Deck() = default;

        inline static Deck makeFullDeck() {return (maxPossibleCardCount);}

        Deck operator+(const Deck& obj) const;
        Deck& operator>>(Deck& obj);
        Card& operator[](size_t number);

        inline size_t size() const {return deck.size();}
        Deck& sort();
        Deck& shuffle();
        Deck& addRandowCard();
        Deck extractByGroup(Card::GROUP group);
        Deck& deleteCard(size_t number);
        bool isAllUniqueCards() const;
        Deck& putCard(const Card&);
        Deck& putCard(const Card&&);

        friend std::ostream& operator<<(std::ostream& os, const Deck& obj);
    };
}

#endif