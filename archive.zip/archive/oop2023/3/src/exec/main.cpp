#include "GameGraphic.h"

using namespace std;
using namespace GameLogic::coord;

#include <algorithm>
#include <queue>
#include <iostream>
int main()
{
    graphic::GameGraphic game;
    game.cycle();
    return 0;
}