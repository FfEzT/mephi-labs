#include "engine/AI.h"

using namespace GameLogic;
using namespace engine;

using coord::Coords;

// TODO
void AI::findPointInterest(const Database& data)
{}

// TODO
void AI::init(coord::Coords fieldSize)
{}