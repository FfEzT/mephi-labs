#pragma once

namespace GameLogic {

    /**
     * @brief Type alias for object IDs.
     */
    using id_t = unsigned int;

} // namespace GameLogic
